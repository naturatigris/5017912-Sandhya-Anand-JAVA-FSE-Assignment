package com.example.BookstoreAPI.Repository;


import com.example.BookstoreAPI.Entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface BookRepository extends JpaRepository<Book, Long> {

    Page<Book> findByTitleContaining(String title, Pageable pageable);

    Page<Book> findByAuthorContaining(String author, Pageable pageable);

    Page<Book> findByTitleContainingAndAuthorContaining(String title, String author, Pageable pageable);
}


