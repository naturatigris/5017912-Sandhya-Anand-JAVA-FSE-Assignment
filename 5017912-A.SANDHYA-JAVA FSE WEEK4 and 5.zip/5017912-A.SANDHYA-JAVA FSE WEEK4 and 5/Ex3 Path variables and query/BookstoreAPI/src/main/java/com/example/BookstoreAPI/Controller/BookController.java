package com.example.BookstoreAPI.Controller;

import com.example.BookstoreAPI.Entity.Book;
import com.example.BookstoreAPI.Repository.BookRepository;
import com.example.BookstoreAPI.Service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookRepository bookRepository;

    public BookController(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Optional<Book> book = bookRepository.findById(id);
        return book.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public Page<Book> getBooks(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author,
            @PageableDefault(size = 10) Pageable pageable) {

        if (title != null && author != null) {
            return bookRepository.findByTitleContainingAndAuthorContaining(title, author, pageable);
        } else if (title != null) {
            return bookRepository.findByTitleContaining(title, pageable);
        } else if (author != null) {
            return bookRepository.findByAuthorContaining(author, pageable);
        } else {
            return bookRepository.findAll(pageable);
        }
    }
}

