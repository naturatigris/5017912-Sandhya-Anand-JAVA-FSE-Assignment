package com.example.BookstoreAPI.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.example.BookstoreAPI.Entity.Customer;

import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
}

