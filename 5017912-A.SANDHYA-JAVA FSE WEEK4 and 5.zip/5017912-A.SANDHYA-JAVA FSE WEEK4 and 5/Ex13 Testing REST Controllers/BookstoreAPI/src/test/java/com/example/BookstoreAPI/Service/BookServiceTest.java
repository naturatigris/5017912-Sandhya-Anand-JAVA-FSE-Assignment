package com.example.BookstoreAPI.Service;

import com.example.BookstoreAPI.DTO.BookDTO;
import com.example.BookstoreAPI.Entity.Book;
import com.example.BookstoreAPI.Repository.BookRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private BookService bookService;

    private Book book1;
    private Book book2;
    private BookDTO bookDTO1;
    private BookDTO bookDTO2;

    @BeforeEach
    public void setUp() {
        book1 = new Book(1L, "Title 1", "Author 1", 10.0);
        book2 = new Book(2L, "Title 2", "Author 2", 15.0);

        bookDTO1 = new BookDTO(1L, "Title 1", "Author 1", 10.0);
        bookDTO2 = new BookDTO(2L, "Title 2", "Author 2", 15.0);
    }

    @Test
    public void testGetAllBooks() {
        when(bookRepository.findAll()).thenReturn(Arrays.asList(book1, book2));
        when(modelMapper.map(book1, BookDTO.class)).thenReturn(bookDTO1);
        when(modelMapper.map(book2, BookDTO.class)).thenReturn(bookDTO2);

        List<BookDTO> books = bookService.getAllBooks();

        assertEquals(2, books.size());
        assertEquals("Title 1", books.get(0).getTitle());
        assertEquals("Title 2", books.get(1).getTitle());
    }

    @Test
    public void testGetBookById() {
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book1));
        when(modelMapper.map(book1, BookDTO.class)).thenReturn(bookDTO1);

        BookDTO book = bookService.getBookById(1L);

        assertEquals("Title 1", book.getTitle());
    }

    @Test
    public void testGetBookById_NotFound() {
        when(bookRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> bookService.getBookById(1L));
    }

    @Test
    public void testSaveBook() {
        when(bookRepository.save(book1)).thenReturn(book1);
        when(modelMapper.map(book1, BookDTO.class)).thenReturn(bookDTO1);

        BookDTO savedBook = bookService.saveBook(bookDTO1);

        assertEquals("Title 1", savedBook.getTitle());
    }

    @Test
    public void testDeleteBook() {
        when(bookRepository.existsById(1L)).thenReturn(true);
        doNothing().when(bookRepository).deleteById(1L);

        bookService.deleteBook(1L);

        verify(bookRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteBook_NotFound() {
        when(bookRepository.existsById(anyLong())).thenReturn(false);

        assertThrows(RuntimeException.class, () -> bookService.deleteBook(1L));
    }
}
