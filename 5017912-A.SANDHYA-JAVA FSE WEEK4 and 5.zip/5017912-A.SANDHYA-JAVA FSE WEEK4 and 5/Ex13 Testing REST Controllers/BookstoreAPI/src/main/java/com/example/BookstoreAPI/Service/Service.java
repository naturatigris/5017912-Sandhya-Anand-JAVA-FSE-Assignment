package com.example.BookstoreAPI.Service;


import com.example.BookstoreAPI.DTO.BookDTO;

import java.util.List;

public interface Service {
    List<BookDTO> getAllBooks();
}
