package com.example.BookstoreAPI.Service;





import com.example.BookstoreAPI.DTO.Bookdto;
import com.example.BookstoreAPI.Entity.Book;
import com.example.BookstoreAPI.Repository.BookRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private ModelMapper modelMapper;

    public List<Bookdto> getAllBooks() {
        return bookRepository.findAll().stream()
                .map(book -> modelMapper.map(book, Bookdto.class))
                .collect(Collectors.toList());
    }

    public Bookdto getBookById(Long id) {
        Book book = bookRepository.findById(id).orElseThrow();
        return modelMapper.map(book, Bookdto.class);
    }

    public Bookdto saveBook(Bookdto bookDTO) {
        Book book = modelMapper.map(bookDTO, Book.class);
        book = bookRepository.save(book);
        return modelMapper.map(book, Bookdto.class);
    }

    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }
}
