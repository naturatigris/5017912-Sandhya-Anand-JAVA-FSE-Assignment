package com.example.BookstoreAPI.Repository;

import com.example.BookstoreAPI.Entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Arrays;
import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {


}
