package com.example.BookstoreAPI.Service;


import com.example.BookstoreAPI.DTO.Customerdto;
import com.example.BookstoreAPI.Entity.Customer;
import com.example.BookstoreAPI.Repository.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ModelMapper modelMapper;

    public List<Customerdto> getAllCustomers() {
        return customerRepository.findAll().stream()
                .map(customer -> modelMapper.map(customer, Customerdto.class))
                .collect(Collectors.toList());
    }

    public Customerdto getCustomerById(Long id) {
        Customer customer = customerRepository.findById(id).orElseThrow();
        return modelMapper.map(customer, Customerdto.class);
    }

    public Customerdto saveCustomer(Customerdto customerDTO) {
        Customer customer = modelMapper.map(customerDTO, Customer.class);
        customer = customerRepository.save(customer);
        return modelMapper.map(customer, Customerdto.class);
    }

    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }
}
