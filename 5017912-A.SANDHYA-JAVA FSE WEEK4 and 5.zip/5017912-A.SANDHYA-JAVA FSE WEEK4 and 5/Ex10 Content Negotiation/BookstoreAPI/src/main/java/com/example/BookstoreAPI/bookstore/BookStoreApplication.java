package com.example.BookstoreAPI.bookstore;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;

public class BookStoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookStoreApplication.class, args);
    }

    @Bean
    public XmlMapper xmlMapper() {
        return new XmlMapper();
    }
}
