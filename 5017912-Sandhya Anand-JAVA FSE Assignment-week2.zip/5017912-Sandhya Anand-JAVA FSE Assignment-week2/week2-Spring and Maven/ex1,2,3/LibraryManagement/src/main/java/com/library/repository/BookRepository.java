package com.library.repository;

public class BookRepository {
    public BookRepository() {}

    public void displayBooks() {
        System.out.println("Displaying books from BookRepository...");
    }
}
