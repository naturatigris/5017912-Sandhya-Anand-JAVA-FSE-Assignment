package com.library.service;


import com.library.repository.BookRepository;
import org.springframework.stereotype.Service;

@Service
public class BookService {
    private BookRepository bookRepository;
    public BookService() {}


    // Setter method for dependency injection
    public void setBookRepository(BookRepository bookRepository) {

        this.bookRepository = bookRepository;
    }

    // Business logic method
    public void manageBooks() {
        System.out.println("Managing books using BookService...");
        bookRepository.displayBooks();
    }

}