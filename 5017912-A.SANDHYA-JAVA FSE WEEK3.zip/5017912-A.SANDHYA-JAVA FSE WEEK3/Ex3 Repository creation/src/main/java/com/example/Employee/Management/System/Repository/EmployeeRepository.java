package com.example.Employee.Management.System.Repository;

import com.example.Employee.Management.System.Entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
}
