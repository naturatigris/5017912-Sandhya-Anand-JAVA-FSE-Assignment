package com.example.Employee.Management.System.Service;

import com.example.Employee.Management.System.Entities.Department;
import com.example.Employee.Management.System.Entities.Employee;
import com.example.Employee.Management.System.Repository.DepartmentRepository;
import com.example.Employee.Management.System.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DepartmentService {


        @Autowired
        private DepartmentRepository departmentRepository;

        public List<Department> getAllDepartments() {
            return departmentRepository.findAll();
        }

        public Department getDepartmentById(Integer id) {
            return departmentRepository.findById(id).orElseThrow(() -> new RuntimeException("Department not found"));
        }

        public Department saveDepartment(Department department) {
            return departmentRepository.save(department);
        }

        public Department updateDepartment(Integer id, Department updatedDepartment) {
            Department existingDepartment = getDepartmentById(id);
            existingDepartment.setName(updatedDepartment.getName());
            return departmentRepository.save(existingDepartment);
        }

        public void deleteDepartment(Integer id) {
            departmentRepository.deleteById(id);
        }
    }

