package com.example.Employee.Management.System.Repository;

import com.example.Employee.Management.System.DTO.EmployeeDTO;
import com.example.Employee.Management.System.Entities.Employee;
import com.example.Employee.Management.System.Projection.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Use projection to get specific fields
    @Query("SELECT new com.example.Employee.Management.System.DTO.EmployeeDTO(e.employeeid, e.employeename, e.deptname, e.employeemail) FROM Employee e")
    List<EmployeeDTO> findEmployeeDTOs();
}

