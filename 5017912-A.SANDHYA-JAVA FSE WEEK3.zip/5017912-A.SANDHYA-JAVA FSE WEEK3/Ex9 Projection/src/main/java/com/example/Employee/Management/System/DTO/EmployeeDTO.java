package com.example.Employee.Management.System.DTO;

public class EmployeeDTO {
    private Long employeeid;
    private String employeename;
    private String employeeemail;
    private String deptname;

    public EmployeeDTO(Long employeeid, String employeename, String employeeemail, String deptname) {
        this.employeeid = employeeid;
        this.employeename = employeename;
        this.employeeemail = employeeemail;
        this.deptname = deptname;
    }

    public Long getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(Long employeeid) {
        this.employeeid = employeeid;
    }

    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }

    public String getEmployeeemail() {
        return employeeemail;
    }

    public void setEmployeeemail(String employeeemail) {
        this.employeeemail = employeeemail;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }
}



