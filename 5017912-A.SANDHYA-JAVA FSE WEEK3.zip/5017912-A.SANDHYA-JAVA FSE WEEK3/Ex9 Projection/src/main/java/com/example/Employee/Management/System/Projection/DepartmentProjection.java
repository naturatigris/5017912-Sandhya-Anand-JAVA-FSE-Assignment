package com.example.Employee.Management.System.Projection;

public interface DepartmentProjection {
    Long getid();
    String getname();
}
