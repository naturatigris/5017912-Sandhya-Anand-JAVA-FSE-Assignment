package com.example.Employee.Management.System.repository;

import com.example.Employee.Management.System.entiity.employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<employee, Integer> {
}