package com.example.Employee.Management.System.service;

import com.example.Employee.Management.System.entiity.employee;

import com.example.Employee.Management.System.repository.EmployeeRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EntityManager entityManager;

    @Transactional
    public void batchInsertEmployees(List<employee> employees) {
        int batchSize = 20;

        for (int i = 0; i < employees.size(); i++) {
            entityManager.persist(employees.get(i));
            if (i % batchSize == 0 && i > 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        // Final flush
        entityManager.flush();
        entityManager.clear();
    }
}