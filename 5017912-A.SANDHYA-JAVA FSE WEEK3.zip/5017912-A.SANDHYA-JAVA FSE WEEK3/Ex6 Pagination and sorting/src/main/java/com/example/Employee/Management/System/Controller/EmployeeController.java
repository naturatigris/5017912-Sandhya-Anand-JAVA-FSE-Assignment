package com.example.Employee.Management.System.Controller;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.ui.Model;
import com.example.Employee.Management.System.Entities.Employee;
import com.example.Employee.Management.System.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public Page<Employee> getEmployees(
            @RequestParam(value = "search", required = false) String search,
            @PageableDefault(size = 10, sort = "lastName") Pageable pageable) {

        if (search != null && !search.isEmpty()) {
            return employeeService.searchEmployeesByFirstName(search, (java.awt.print.Pageable) pageable);
        } else {
            return employeeService.getEmployees((java.awt.print.Pageable) pageable);
        }
    }
}
