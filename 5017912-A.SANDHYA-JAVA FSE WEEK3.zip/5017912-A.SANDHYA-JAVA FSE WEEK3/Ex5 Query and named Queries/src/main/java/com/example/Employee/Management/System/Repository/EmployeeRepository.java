package com.example.Employee.Management.System.Repository;

import com.example.Employee.Management.System.Entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    @Query("SELECT e FROM Employee e WHERE e.employeename = ?1")
    List<Employee> findEmployeesByFirstName(String firstName);

    @Query("SELECT e FROM Employee e WHERE e.employeemail = :email")
    Employee findEmployeeByEmail(String email);

    @Query("SELECT e FROM Employee e WHERE e.employeename LIKE %:substring%")
    List<Employee> findEmployeesByNameContaining(String substring);

}
