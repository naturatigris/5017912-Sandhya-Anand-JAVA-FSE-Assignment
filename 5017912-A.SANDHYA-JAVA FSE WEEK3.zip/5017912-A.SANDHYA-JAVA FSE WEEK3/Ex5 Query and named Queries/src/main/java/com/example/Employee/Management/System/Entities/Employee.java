package com.example.Employee.Management.System.Entities;


import jakarta.persistence.*;
import org.hibernate.annotations.Type;


import org.hibernate.annotations.Type;

@Entity
@NamedQueries({
        @NamedQuery(name = "Employee.findByFirstName",
                query = "SELECT e FROM Employee e WHERE e.employeename = :EmployeeName"),
        @NamedQuery(name = "Employee.findByEmailName",
                query = "SELECT e FROM Employee e WHERE e.employeemail = :EmailName")
})

public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employeeid;

    @Column(name = "employeename", nullable = false)
    private String employeename;

    @Column(name="employeemail", nullable = false)
    private String employeemail;

    @Column(name="deptname", nullable = false)
    private String deptname;

    public Long getEmployeeid() {
        return employeeid;
    }

    public void setEmployeeid(Long employeeid) {
        this.employeeid = employeeid;
    }

    public String getEmployeename() {
        return employeename;
    }

    public void setEmployeename(String employeename) {
        this.employeename = employeename;
    }

    public String getEmployeemail() {
        return employeemail;
    }

    public void setEmployeemail(String employeemail) {
        this.employeemail = employeemail;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

}





