package com.example.Employee.Management.System.Entities;


import jakarta.persistence.*;
import org.hibernate.annotations.Type;


import org.hibernate.annotations.Type;

@Entity

public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employeeid;
    private String employeename;
    private String employeemail;
    private String deptname;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

}





