package com.example.Employee.Management.System.controller;

import com.example.Employee.Management.System.entiity.primary.primaryentity;
import com.example.Employee.Management.System.service.PrimaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/primary")
public class PrimaryController {

    @Autowired
    private PrimaryService primaryService;

    @PostMapping("/save")
    public primaryentity savePrimaryEntity(@RequestBody primaryentity entity) {
        return primaryService.savePrimaryEntity(entity);
    }

    @GetMapping("/{id}")
    public primaryentity getPrimaryEntity(@PathVariable Long id) {
        return primaryService.getPrimaryEntity(id);
    }
}