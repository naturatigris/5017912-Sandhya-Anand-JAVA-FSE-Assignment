package com.example.Employee.Management.System.service;

import com.example.Employee.Management.System.entiity.primary.primaryentity;
import com.example.Employee.Management.System.repository.primary.primaryrepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PrimaryService {
    @PersistenceContext(unitName = "primaryEntityManagerFactory")
    private EntityManager primaryEntityManager;

    public void performPrimaryOperation() {
    }

    @Autowired
    private primaryrepository primaryRepository;

    public primaryentity savePrimaryEntity(primaryentity entity) {
        primaryRepository.save(entity);
        return entity;
    }

    public primaryentity getPrimaryEntity(Long id) {
        return primaryRepository.findById(id).orElse(null);
    }
}
