package com.example.Employee.Management.System.repository.primary;

import com.example.Employee.Management.System.entiity.primary.primaryentity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface primaryrepository extends JpaRepository<primaryentity,Long> {
}
