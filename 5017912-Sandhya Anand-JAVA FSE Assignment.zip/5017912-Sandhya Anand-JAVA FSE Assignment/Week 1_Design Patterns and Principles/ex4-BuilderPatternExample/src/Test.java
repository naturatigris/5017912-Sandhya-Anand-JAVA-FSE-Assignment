public class Test  {
    public static void main(String[] args) {
        // Using the builder to create a Computer instance
        Computer computer = new Computer.ComputerBuilder()
                .setCPU("Intel i7")
                .setRAM("128GB")
                .setStorage("1TB SSD")

                .build();

        // Display the Computer details
        System.out.println(computer);
    }
}

