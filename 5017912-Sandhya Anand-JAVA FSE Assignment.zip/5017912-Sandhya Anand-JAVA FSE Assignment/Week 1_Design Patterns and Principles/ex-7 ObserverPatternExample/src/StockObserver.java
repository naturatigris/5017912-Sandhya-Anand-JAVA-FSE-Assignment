public class StockObserver implements Observer {
        private String name;

        public StockObserver(String name) {
            this.name = name;
        }


        @Override
        public void update(String stockSymbol, double stockValue) {
            System.out.println("Notification to " + name + ": Stock " + stockSymbol + " is now " + stockValue);
        }
    }


