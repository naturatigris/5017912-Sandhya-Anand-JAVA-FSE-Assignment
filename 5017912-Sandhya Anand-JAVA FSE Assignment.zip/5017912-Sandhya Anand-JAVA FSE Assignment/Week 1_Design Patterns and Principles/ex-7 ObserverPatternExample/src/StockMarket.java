import java.util.ArrayList;
import java.util.List;

public class StockMarket implements Stock {
    private List<Observer> observers=new ArrayList<>();
    private String stockSymbol;
    private double stockValue;



    @Override
    public void register(Observer o) {
        observers.add(o);
    }

    @Override
    public void deregister(Observer o) {
        observers.remove(o);
    }

    @Override
    public void notifyobservers() {
        for (Observer observer : observers) {
            observer.update(stockSymbol, stockValue);
        }

    }



    public void setStockValue(String stockSymbol, double stockValue) {
        this.stockSymbol = stockSymbol;
        this.stockValue = stockValue;
        notifyobservers();
    }
}
