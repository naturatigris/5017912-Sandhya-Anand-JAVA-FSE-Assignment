package org.StudyEasy;

public class PDFDocumentFactory extends DocumentFactory {
    @Override
    protected document create() {
        return new PDFDocument();
    }
}
