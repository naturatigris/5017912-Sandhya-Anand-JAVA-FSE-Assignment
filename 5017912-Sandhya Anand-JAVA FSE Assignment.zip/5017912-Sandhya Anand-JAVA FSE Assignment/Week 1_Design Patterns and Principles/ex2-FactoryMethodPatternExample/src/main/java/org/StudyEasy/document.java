package org.StudyEasy;

public interface document {
    void open();
    void read();
    void write(String content);
    void close();
}
