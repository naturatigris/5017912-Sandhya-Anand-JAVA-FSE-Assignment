package org.StudyEasy;

public class PDFDocument implements document {
    @Override
    public void open() {
        System.out.println("Opening PDF document.");
    }

    @Override
    public void read() {
        System.out.println("Reading PDF document.");
    }

    @Override
    public void write(String content) {
        System.out.println("Writing to PDF document: " + content);
    }

    @Override
    public void close() {
        System.out.println("Closing PDF document.");
    }
}
