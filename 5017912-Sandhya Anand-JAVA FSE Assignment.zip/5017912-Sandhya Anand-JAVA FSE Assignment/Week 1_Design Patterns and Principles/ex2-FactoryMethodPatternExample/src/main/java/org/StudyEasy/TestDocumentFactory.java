package org.StudyEasy;

public class TestDocumentFactory {
    public static void main(String[] args) {
        DocumentFactory pdfFactory = new PDFDocumentFactory();
        DocumentFactory wordFactory = new WordDocumentFactory();
        DocumentFactory excelFactory = new ExcelDocumentFactory();

        pdfFactory.createDocument();
        wordFactory.createDocument();
        excelFactory.createDocument();
    }
}
