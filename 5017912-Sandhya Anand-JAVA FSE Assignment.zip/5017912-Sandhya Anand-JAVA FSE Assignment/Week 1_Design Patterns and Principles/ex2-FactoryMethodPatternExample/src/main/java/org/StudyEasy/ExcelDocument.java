package org.StudyEasy;

public class ExcelDocument implements document {
    @Override
    public void open() {
        System.out.println("Opening Excel document.");
    }

    @Override
    public void read() {
        System.out.println("Reading Excel document.");
    }

    @Override
    public void write(String content) {
        System.out.println("Writing to Excel document: " + content);
    }

    @Override
    public void close() {
        System.out.println("Closing Excel document.");
    }
}
