package org.StudyEasy;

public class WordDocument implements document {
    @Override
    public void open() {
        System.out.println("Opening Word document.");
    }

    @Override
    public void read() {
        System.out.println("Reading Word document.");
    }

    @Override
    public void write(String content) {
        System.out.println("Writing to Word document: " + content);
    }

    @Override
    public void close() {
        System.out.println("Closing Word document.");
    }
}
