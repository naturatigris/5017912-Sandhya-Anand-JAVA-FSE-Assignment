import java.util.HashMap;
import java.util.Map;
public class ProxyImage implements Image {
    private RealImage Realimage;
    private String url;
    private HashMap<String,RealImage>ImageCache=new HashMap<>();
    public ProxyImage(String url) {
        this.url = url;
    }
    @Override
    public void display() {
        if (Realimage == null) {
            Realimage=ImageCache.get(url);
            if (Realimage == null) {
                Realimage=new RealImage(url);
                ImageCache.put(url,Realimage);
            }
        }
        Realimage.display();
    }
}
