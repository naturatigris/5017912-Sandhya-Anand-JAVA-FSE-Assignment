package org.StudyEasy;


public class CustomerRepositoryImpl implements CustomerRepository {

    @Override
    public Customer findCustomerById(int id) {
        // For demonstration purposes, we return a static customer
        return new Customer(id, "John Doe");
    }
}

