package org.StudyEasy;

public interface CustomerRepository {
    Customer findCustomerById(int id);
}
