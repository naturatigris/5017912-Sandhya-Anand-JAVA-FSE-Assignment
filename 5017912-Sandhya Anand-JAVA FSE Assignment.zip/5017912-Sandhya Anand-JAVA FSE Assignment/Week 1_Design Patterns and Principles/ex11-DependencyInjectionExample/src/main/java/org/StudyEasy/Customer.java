package org.StudyEasy;

import java.util.*;
import java.lang.*;

public class Customer {
    public int id;
    public String name;

    public Customer(int id, String name) {
        this.id = id;
        this.name = name;
    }



    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Customer{id=" + id + ", name='" + name + '\'' + '}';
    }
}

