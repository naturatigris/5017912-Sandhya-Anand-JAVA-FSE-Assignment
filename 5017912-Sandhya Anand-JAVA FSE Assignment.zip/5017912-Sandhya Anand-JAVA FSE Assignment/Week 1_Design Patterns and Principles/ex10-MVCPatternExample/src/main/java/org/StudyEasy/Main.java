package org.StudyEasy;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
// MVCPatternExample.java

import org.StudyEasy.Student;
import org.StudyEasy.StudentView;
import org.StudyEasy.StudentController;

public class Main {
    public static void main(String[] args) {
        // Create a new student
        Student student = new Student("1", "John Doe", "A");

        // Create the view
        StudentView view = new StudentView();

        // Create the controller
        StudentController controller = new StudentController(student, view);

        // Display initial details
        controller.updateView();

        // Update the student details
        controller.setStudentName("Jane Doe");
        controller.setStudentGrade("B");

        // Display updated details
        controller.updateView();
    }
}
