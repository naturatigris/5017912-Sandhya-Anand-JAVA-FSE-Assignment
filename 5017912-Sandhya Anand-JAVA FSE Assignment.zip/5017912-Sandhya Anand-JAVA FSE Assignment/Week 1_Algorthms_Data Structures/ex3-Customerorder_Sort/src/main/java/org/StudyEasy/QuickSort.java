package org.StudyEasy;

import java.util.ArrayList;

public class QuickSort {
    public static ArrayList<order> quickSort(ArrayList<order> arr, int low, int high) {
       if (low < high) {
            int pi = partition(arr, low, high);

            quickSort(arr, low, pi - 1);
            quickSort(arr, pi + 1, high);
        }
        return arr;
    }

    private static int partition(ArrayList<order> arr, int low, int high) {
        order pivot = arr.get(high);
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (arr.get(j).getTotalprice() <= pivot.getTotalprice()) {
                i++;

                order temp = arr.get(i);
                arr.set(i, arr.get(j));
                arr.set(j, temp);
            }
        }

        order temp = arr.get(i + 1);
        arr.set(i + 1, arr.get(high));
        arr.set(high, temp);

        return i + 1;
    }
}
