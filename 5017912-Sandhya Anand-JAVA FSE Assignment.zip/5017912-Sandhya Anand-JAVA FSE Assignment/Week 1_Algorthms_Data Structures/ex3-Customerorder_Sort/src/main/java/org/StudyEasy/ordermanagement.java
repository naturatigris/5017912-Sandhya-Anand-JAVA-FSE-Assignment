package org.StudyEasy;
import java.util.*;
public class ordermanagement {
    public ArrayList<order> orders;
    public ordermanagement(){
        this.orders=  new ArrayList<>();
    }
    public void addItem(order order) {
        orders.add(order);
    }

    public void removeItem(String customername) {
        orders.removeIf(product -> product.getCustomername().equalsIgnoreCase(customername));
    }
    public void displayInventory() {
        for (order order : orders) {
            System.out.println(orders);
        }
    }
    public ArrayList<order> getorderList() {
        return orders;
    }


}
