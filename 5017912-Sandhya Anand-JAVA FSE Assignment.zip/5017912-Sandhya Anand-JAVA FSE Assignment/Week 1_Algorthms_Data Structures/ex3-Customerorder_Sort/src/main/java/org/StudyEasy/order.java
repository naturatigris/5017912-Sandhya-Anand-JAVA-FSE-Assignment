package org.StudyEasy;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class order {
    public int orderID;
    public String customername;
    private double totalprice;

    public order(int orderID,String name, double totalprice) {
        this.orderID=orderID;
        this.customername = name;
        this.totalprice = totalprice;
    }

    public int getOrderID() {
        return orderID;
    }

    public double getTotalprice() {
        return totalprice;
    }

    public String getCustomername() {
        return customername;
    }

    @Override
    public String toString() {
        return "orderId="+ orderID +", customername="+customername+", totalprice="+totalprice;
    }
}