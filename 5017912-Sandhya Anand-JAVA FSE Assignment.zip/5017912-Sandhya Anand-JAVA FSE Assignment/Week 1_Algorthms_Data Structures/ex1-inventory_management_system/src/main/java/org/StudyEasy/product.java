package org.StudyEasy;

public class product {
    public int productID;
    public String productname;
    private int quantity;
    private double price;

    public product(int productID,String name, int quantity, double price) {
        this.productID=productID;
        this.productname = name;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters and setters
    public String getName() {
        return productname;
    }

    public void setName(String name) {
        this.productname = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Item{" +
                "id="+ productID+
                ", name='" + productname + '\'' +
                ", quantity=" + quantity +
                ", price=" + price +
                '}';
    }
}