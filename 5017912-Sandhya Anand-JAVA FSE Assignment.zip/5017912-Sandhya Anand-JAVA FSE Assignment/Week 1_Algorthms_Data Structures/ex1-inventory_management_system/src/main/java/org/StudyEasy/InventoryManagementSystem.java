package org.StudyEasy;

public class InventoryManagementSystem {
    public static void main(String[] args) {
        inventory inventory = new inventory();

        // Adding items
        inventory.addItem(new product(01, "apple", 2,50));
        inventory.addItem(new product(02,"Banana", 100, 0.30));

        // Display inventory
        System.out.println("Initial Inventory:");
        inventory.displayInventory();

        // Update item quantity
        inventory.updateItemQuantity("Apple", 60);

        // Display inventory after update
        System.out.println("\nInventory after updating Apple quantity:");
        inventory.displayInventory();

        // Remove an item
        inventory.removeItem("Banana");

        // Display inventory after removing an item
        System.out.println("\nInventory after removing Banana:");
        inventory.displayInventory();
    }
}
