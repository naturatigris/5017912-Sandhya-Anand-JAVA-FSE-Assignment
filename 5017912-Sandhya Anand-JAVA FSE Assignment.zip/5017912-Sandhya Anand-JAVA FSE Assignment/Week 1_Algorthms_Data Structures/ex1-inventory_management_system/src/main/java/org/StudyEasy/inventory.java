package org.StudyEasy;

import java.util.HashMap;
import java.util.Map;
import org.StudyEasy.product.*;

public class inventory {
    private Map<String, product> items;

    public inventory() {
        this.items = new HashMap<>();
    }

    // Add item to inventory
    public void addItem(product product) {
        items.put(product.getName(), product);
    }

    // Remove item from inventory
    public void removeItem(String name) {
        items.remove(name);
    }

    // Update item quantity
    public void updateItemQuantity(String name, int quantity) {
        product item = items.get(name);
        if (item != null) {
            item.setQuantity(quantity);
        }
    }
    public void updateItemPrice(String name, int price) {
        product item = items.get(name);
        if (item != null) {
            item.setPrice(price);
        }
    }

    // Display inventory
    public void displayInventory() {
        for (product item : items.values()) {
            System.out.println(item);
        }
    }

    // Get item
    public product getItem(String name) {
        return items.get(name);
    }
}
