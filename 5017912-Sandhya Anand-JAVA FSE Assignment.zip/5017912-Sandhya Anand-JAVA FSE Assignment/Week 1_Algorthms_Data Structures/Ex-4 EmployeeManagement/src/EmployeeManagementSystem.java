public class EmployeeManagementSystem {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManagerImpl(10);

        // Adding employees
        manager.addEmployee(new Employee(1, "James", " Machine Learning Engineering", 70000));
        manager.addEmployee(new Employee(2, "Akshay", "Digital Marketing", 65000));
        manager.addEmployee(new Employee(3,"Ibrahim","software Developer",60000));

        // Traverse employees
        System.out.println("All Employees:");
        manager.traverseEmployees();

        // Search employee
        System.out.println("\nSearching for Employee with ID 1:");
        Employee employee = manager.searchEmployee(1);
        if (employee != null) {
            System.out.println(employee);
        } else {
            System.out.println("Employee not found.");
        }

        // Delete employee
        System.out.println("\nDeleting Employee with ID 3:");
        manager.deleteEmployee(3);

        // Traverse employees after deletion
        System.out.println("\nAll Employees after deletion:");
        manager.traverseEmployees();
    }
}
