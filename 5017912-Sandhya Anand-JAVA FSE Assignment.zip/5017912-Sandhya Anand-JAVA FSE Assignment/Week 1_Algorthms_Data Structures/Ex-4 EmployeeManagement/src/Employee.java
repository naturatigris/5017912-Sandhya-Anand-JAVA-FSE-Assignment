public class Employee {
    private int employeeid;
    private String name;
    private String position;
    private double salary;

    public Employee(int employeeid, String name, String position, double salary) {
        this.employeeid = employeeid;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Getters and setters
    public int getEmployeeId() {
        return employeeid;
    }


    public String getName() {
        return name;
    }



    public String getPosition() {
        return position;
    }



    public double getSalary() {
        return salary;
    }



    @Override
    public String toString() {
        return "Employee{" +
                "employeeid=" + employeeid +
                ", name='" + name + '\'' +
                ", position='" + position+ '\'' +
                ", salary=" + salary +
                '}';
    }
}

