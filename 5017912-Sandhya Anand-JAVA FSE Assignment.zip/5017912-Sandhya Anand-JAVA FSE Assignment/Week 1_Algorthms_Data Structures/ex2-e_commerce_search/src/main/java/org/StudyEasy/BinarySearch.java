package org.StudyEasy;

import java.util.List;

public class BinarySearch {
    public static product binarySearch(List<product> productList, int productID,int count) {
        int start=0;
        int end=count;
        while (start<end){
            int mid=(start+end)/2;
            product product=productList.get(mid);
            if (product.getProductID() == productID){
                return product;
            }else if(product.getProductID() < productID){
                end=mid-1;

            }else{
                start=mid+1;
            }
        }

        return null; // return null if the productID is not found
    }
}


