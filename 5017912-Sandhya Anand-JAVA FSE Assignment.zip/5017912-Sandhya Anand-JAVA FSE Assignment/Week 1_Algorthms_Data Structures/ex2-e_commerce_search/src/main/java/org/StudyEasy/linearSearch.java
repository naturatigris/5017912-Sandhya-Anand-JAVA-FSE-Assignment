package org.StudyEasy;

import java.util.List;

public class linearSearch {
    public static product linearSearch(List<product> productList, int productID) {
        for (product product : productList) {
            if (product.getProductID() == productID) {
                return product;
            }
        }
        return null; // return null if the productID is not found
    }
}
